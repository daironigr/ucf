package com.ucf.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.ucf.models.Consejo;
import com.ucf.models.Contacto;
import com.ucf.models.Etapa;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * Created by Apple on 17/4/2018.
 */


public class SQLHelper extends SQLiteOpenHelper {
    private static String DB_PATH = "data/data/com.ucf/databases/";
    private static String DB_NAME = "database.db";
    private SQLiteDatabase database;
    private final Context context;

    public SQLHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.context = context;

        if (!checkDatabase()) {
            try {
                copyDatabase();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        database = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void createDatabase() {
        boolean dbExist = checkDatabase();
        if (!dbExist) {

            try {
                copyDatabase();
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.getReadableDatabase();
        }
    }

    private boolean checkDatabase() {
        File db = new File(context.getDatabasePath(DB_NAME).getPath());
        Log.d("DBPATH", "DB path is " + db.getPath());
        if (db.exists()) {
            return true;
        }

        File dbdir = db.getParentFile();
        if (!dbdir.exists()) {
            db.getParentFile().mkdirs();
            dbdir.mkdirs();
        }
        return false;
    }

    public void open() {
        String path = DB_PATH + DB_NAME;

        database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE);
    }

    public synchronized void close() {
        if (database != null) {
            database.close();
        }
        super.close();
    }

    private void copyDatabase() throws IOException {
        try {
            InputStream inputStream = context.getAssets().open(DB_NAME);
            String outputFileName = context.getDatabasePath(DB_NAME).getPath();
            Log.d("LIFECYCLE", outputFileName);
            OutputStream outputStream = new FileOutputStream(outputFileName);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.flush();
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Etapa getEtapa(int id) {
        String columns[] = new String[]{
                "id",
                "titulo",
                "texto"
        };
        Cursor cursor = database.query("etapas", columns, "id=" + String.valueOf(id), null, null, null, null);
        cursor.moveToFirst();
        String titulo = cursor.getString(cursor.getColumnIndexOrThrow("titulo"));
        String texto = cursor.getString(cursor.getColumnIndexOrThrow("texto"));

        return new Etapa(titulo, texto);
    }

    public ArrayList<Etapa> getEtapas() {
        String columns[] = new String[]{
                "id",
                "titulo",
                "texto"
        };
        Cursor cursor = database.query("etapas", columns, null, null, null, null, null);
        ArrayList<Etapa> etapas = new ArrayList<>();

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            String titulo = cursor.getString(cursor.getColumnIndexOrThrow("titulo"));
            String texto = cursor.getString(cursor.getColumnIndexOrThrow("texto"));

            etapas.add(new Etapa(titulo, texto));
        }


        return etapas;
    }

    public ArrayList<Contacto> getContactos() {
        String columns[] = new String[]{
                "departamento",
                "responsable",
                "telefono",
                "servicio",
                "sede"
        };
        Cursor cursor = database.query("directorio", columns, null, null, null, null, null);
        ArrayList<Contacto> contactos = new ArrayList<>();

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            String departamento = cursor.getString(cursor.getColumnIndexOrThrow("departamento"));
            String responsable = cursor.getString(cursor.getColumnIndexOrThrow("responsable"));
            String telefono = cursor.getString(cursor.getColumnIndexOrThrow("telefono"));
            String servicio = cursor.getString(cursor.getColumnIndexOrThrow("servicio"));
            String sede = cursor.getString(cursor.getColumnIndexOrThrow("sede"));

            contactos.add(new Contacto(departamento, responsable, telefono, servicio, sede));
        }

        cursor.close();
        return contactos;
    }

    public ArrayList<Contacto> searchContacto(String search) {
        search.replace(' ', '%');
        search = '%' + search + '%';
        String columns[] = new String[]{
                "departamento",
                "responsable",
                "telefono",
                "servicio",
                "sede"
        };
        Cursor cursor = database.query("directorio", columns, "departamento like '" + search + "' or responsable like '" + search + "' or telefono like '" + search + "' or servicio like '" + search + "' or sede like '" + search + "'", null, null, null, null);
        ArrayList<Contacto> data_row = new ArrayList<>();

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            String departamento = cursor.getString(cursor.getColumnIndexOrThrow("departamento"));
            String responsable = cursor.getString(cursor.getColumnIndexOrThrow("responsable"));
            String telefono = cursor.getString(cursor.getColumnIndexOrThrow("telefono"));
            String servicio = cursor.getString(cursor.getColumnIndexOrThrow("servicio"));
            String sede = cursor.getString(cursor.getColumnIndexOrThrow("sede"));

            data_row.add(new Contacto(departamento, responsable, telefono, servicio, sede));

        }
        cursor.close();
        return data_row;
    }

    public ArrayList<Consejo> getConsejo() {
        String columns[] = new String[]{
                "cargo",
                "nombre",
                "correo",
                "image"
        };
        Cursor cursor = database.query("consejo", columns, null, null, null, null, null);
        ArrayList<Consejo> direccion = new ArrayList<>();

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            String cargo = cursor.getString(cursor.getColumnIndexOrThrow("cargo"));
            String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombre"));
            String correo = cursor.getString(cursor.getColumnIndexOrThrow("correo"));
            byte[] image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"));

            direccion.add(new Consejo(cargo, nombre, correo, image));
        }

        cursor.close();
        return direccion;
    }
    public Consejo getDecano(int id) {
        String columns[] = new String[]{
                "cargo",
                "nombre",
                "correo",
                "image"
        };
        Cursor cursor = database.query("consejo", columns, "id="+String.valueOf(id), null, null, null, null);
        Consejo decano = new Consejo("", "", "", new byte[]{});
        if(cursor.moveToFirst()){
            String cargo = cursor.getString(cursor.getColumnIndexOrThrow("cargo"));
            String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombre"));
            String correo = cursor.getString(cursor.getColumnIndexOrThrow("correo"));
            byte[] image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"));

            decano = new Consejo(cargo, nombre, correo, image);
        }

        cursor.close();
        return decano;
    }

}