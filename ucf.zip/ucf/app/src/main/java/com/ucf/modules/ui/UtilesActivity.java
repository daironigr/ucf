package com.ucf.modules.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.ucf.R;

public class UtilesActivity extends AppCompatActivity {
    ImageView correo, internet, cuenta, antivirus, directorio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utiles);

        correo = findViewById(R.id.img_correo);
        internet = findViewById(R.id.img_internet);
        cuenta = findViewById(R.id.img_cuenta);
        antivirus = findViewById(R.id.img_antivirus);
        directorio = findViewById(R.id.img_directorio);

    }

    public void openUrl(View view){
        String url = "";
        switch (view.getId()){
            case R.id.cv_libros:
                url = "https://webmail.ucf.edu.cu";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_multimedia:
                url = "https://siccip.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_editorial:
                url = "http://micuenta.ucf.edu.cu/login";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_posgrado:
                url = "http://updates.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_directorio:
                url = "https://webmail.ucf.edu.cu";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;

        }
    }
}
