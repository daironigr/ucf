package com.ucf.modules.ui.ui.somos;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.nightonke.boommenu.BoomButtons.ButtonPlaceEnum;
import com.nightonke.boommenu.BoomButtons.HamButton;
import com.nightonke.boommenu.BoomButtons.OnBMClickListener;
import com.nightonke.boommenu.BoomButtons.SimpleCircleButton;
import com.nightonke.boommenu.BoomMenuButton;
import com.nightonke.boommenu.Piece.PiecePlaceEnum;
import com.ucf.R;
import com.ucf.modules.ui.ui.centrosestudios.CEstudiosFragment;
import com.ucf.modules.ui.ui.consejocientifico.CCientificoFragment;
import com.ucf.modules.ui.ui.consejodireccion.ConsejoDireccionFragment;
import com.ucf.modules.ui.ui.editorialuniverso.EUniversoFragment;
import com.ucf.modules.ui.ui.estudios.EstudiosFragment;
import com.ucf.modules.ui.ui.lineas.LineasInvFragment;

public class SomosFragment extends Fragment {
    BoomMenuButton bmb;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View root = inflater.inflate(R.layout.fragment_somos, null);
        bmb = root.findViewById(R.id.bmb_somos);
//        bmb.setPiecePlaceEnum(PiecePlaceEnum.DOT_4_1);
//        bmb.setButtonPlaceEnum(ButtonPlaceEnum.SC_7_1);
        bmb.setNormalColor(R.color.colorPrimaryDark);
        bmb.setHighlightedColor(R.color.colorPrimaryDark);
        for (int i = 0; i < bmb.getButtonPlaceEnum().buttonNumber(); i++) {
            HamButton.Builder builder;
            switch (i) {
                case 0:
                    builder = new HamButton.Builder()
                            .normalImageRes(R.drawable.icon)
                            .normalText("Lineas de Investigacion")
                            .normalColorRes(R.color.colorAccent)
                            .highlightedColorRes(R.color.colorAccent)
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.replace(R.id.container_body, new LineasInvFragment()).addToBackStack(null).commit();
                                }
                            });
                    bmb.addBuilder(builder);
                    break;
                case 1:
                    builder = new HamButton.Builder()
                            .normalImageRes(R.drawable.icon)
                            .normalText("Centros de Estudio")
                            .normalColorRes(R.color.colorPrimaryDark)
                            .highlightedColorRes(R.color.colorPrimaryDark)
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.replace(R.id.container_body, new CEstudiosFragment()).addToBackStack(null).commit();
                                }
                            });
                    bmb.addBuilder(builder);
                    break;
                case 2:
                    builder = new HamButton.Builder()
                            .normalImageRes(R.drawable.icon)
                            .normalText("Editorial y Catedras Honorificas")
                            .normalColorRes(R.color.colorAccent)
                            .highlightedColorRes(R.color.colorAccent)
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.replace(R.id.container_body, new EUniversoFragment()).addToBackStack(null).commit();
                                }
                            });
                    bmb.addBuilder(builder);
                    break;
                case 3:
                    builder = new HamButton.Builder()
                            .normalImageRes(R.drawable.icon)
                            .normalText("Consejo de Direccion")
                            .normalColorRes(R.color.colorAccent)
                            .highlightedColorRes(R.color.colorAccent)
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.replace(R.id.container_body, new ConsejoDireccionFragment()).addToBackStack(null).commit();
                                }
                            });
                    bmb.addBuilder(builder);
                    break;
                case 4:
                    builder = new HamButton.Builder()
                            .normalImageRes(R.drawable.icon)
                            .normalText("Consejo Cientifico")
                            .normalColorRes(R.color.colorPrimaryDark)
                            .highlightedColorRes(R.color.colorPrimaryDark)
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.replace(R.id.container_body, new CCientificoFragment()).addToBackStack(null).commit();
                                }
                            });
                    bmb.addBuilder(builder);
                    break;
                case 5:
                    builder = new HamButton.Builder()
                            .normalImageRes(R.drawable.icon)
                            .normalText("Estudios")
                            .normalColorRes(R.color.colorPrimaryDark)
                            .highlightedColorRes(R.color.colorPrimaryDark)
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.replace(R.id.container_body, new EstudiosFragment()).addToBackStack(null).commit();
                                }
                            });
                    bmb.addBuilder(builder);
                    break;
            }

        }
        return root;
    }
}
