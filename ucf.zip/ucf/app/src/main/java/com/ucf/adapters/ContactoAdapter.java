package com.ucf.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ucf.R;
import com.ucf.models.Contacto;

import java.util.ArrayList;
import java.util.List;

import static com.ucf.utils.Utiles.call;

//public class ContactoAdapter extends RecyclerView.Adapter<ContactoAdapter.ViewHolder> {
//
//    private List<Contacto> contactos;
//    private LayoutInflater inflater;
//    private Context context;
//    private Activity activity;
//
//    public ContactoAdapter(List<Contacto> contactos, Context context, Activity activity) {
//        this.contactos = contactos;
//        this.context = context;
//        this.activity = activity;
//        this.inflater = LayoutInflater.from(context);
//
//    }
//
//    @NonNull
//    @Override
//    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = inflater.inflate(R.layout.item_contacto, parent, false);
//        return new ViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
//        final Contacto contacto = contactos.get(position);
//        holder.departamento.setText(contacto.departamento);
//        holder.responsable.setText(contacto.responsable);
//        holder.telefono.setText(contacto.telefono);
//        holder.servicio.setText(contacto.servicio);
//        holder.sede.setText(contacto.sede);
//
//        holder.telefono.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                call(contacto.telefono, context, activity);
//                return true;
//            }
//        });
//    }
//
//    @Override
//    public int getItemCount() {
//        return contactos.size();
//    }
//
//    class ViewHolder extends RecyclerView.ViewHolder{
//        TextView departamento, responsable, telefono, servicio, sede;
//
//        ViewHolder(View itemView){
//            super(itemView);
//            departamento = itemView.findViewById(R.id.txt_departamento);
//            responsable = itemView.findViewById(R.id.txt_responsable);
//            telefono = itemView.findViewById(R.id.txt_telefono);
//            servicio = itemView.findViewById(R.id.txt_servicio);
//            sede = itemView.findViewById(R.id.txt_sede);
//        }
//
//
//    }
//    Contacto getItem(int id){
//        return contactos.get(id);
//    }
//}

public class ContactoAdapter extends BaseAdapter {
    private ArrayList<Contacto> contactos;
    private LayoutInflater inflater;
    private Context context;
    private Activity activity;

    public ContactoAdapter(ArrayList<Contacto> contactos, Context context, Activity activity) {
        this.contactos = contactos;
        this.context = context;
        this.activity = activity;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
    @Override
    public int getCount() {
        return contactos.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_contacto, null);
        final Contacto contacto = contactos.get(position);
        TextView departamento, responsable, telefono, servicio, sede;

        ImageView icon = convertView.findViewById(R.id.img_contacto);
        departamento = convertView.findViewById(R.id.txt_departamento);
        responsable = convertView.findViewById(R.id.txt_responsable);
        telefono = convertView.findViewById(R.id.txt_telefono);
        servicio = convertView.findViewById(R.id.txt_servicio);
//        sede = convertView.findViewById(R.id.txt_sede);

        departamento.setText(contacto.departamento);
        responsable.setText(contacto.responsable);
        telefono.setText(contacto.telefono);
        servicio.setText(contacto.servicio + " | " + contacto.sede);
//        sede.setText(contacto.sede);
        telefono.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                call(contacto.telefono, context, activity);
                return true;
            }
        });
        icon.setImageResource(R.drawable.ic_user);
        return convertView;
    }
}
