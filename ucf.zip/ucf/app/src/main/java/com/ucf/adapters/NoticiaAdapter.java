package com.ucf.adapters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ucf.R;
import com.ucf.models.Noticia;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static androidx.core.content.ContextCompat.startActivity;

/**
 * Created by Dairon Ian on 9/8/2019.
 */

public class NoticiaAdapter extends RecyclerView.Adapter<NoticiaAdapter.MyViewHolder> {

    private ArrayList<Noticia> noticias = new ArrayList<>();
    private int lastPosition = -1;
    private AppCompatActivity activity;

    public NoticiaAdapter(ArrayList<Noticia> noticias, AppCompatActivity activity) {
        this.noticias = noticias;
        this.activity = activity;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        private TextView titulo, resumen, link, tipo;
        private ImageView img;
        public MyViewHolder(View view){
            super(view);
            titulo =  view.findViewById(R.id.txt_titulo);
            resumen = view.findViewById(R.id.txt_resumen);
            link = view.findViewById(R.id.txt_link);
            img =  view.findViewById(R.id.img_portada_noticia);
            tipo = view.findViewById(R.id.txt_tipo);
        }
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_noticia, parent, false);

        return new MyViewHolder(itemView);
    }


    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final Noticia noticia = noticias.get(position);
        holder.titulo.setText(noticia.titulo);
        holder.resumen.setText(noticia.resumen);
        holder.link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(noticia.link));
                activity.startActivity(intent);
            }
        });
        holder.tipo.setText(noticia.tipo);
        if(noticia.img_res == -1) {
            Glide.with(activity.getApplicationContext()).load(noticia.link_img).into(holder.img);
//        downloadFile(noticia.link_img, holder.img);
        }else{
            holder.img.setImageResource(noticia.img_res);
        }
        if(position%2 == 0){
            holder.itemView.setBackgroundResource(R.color.colorAccent);
        }else{
            holder.itemView.setBackgroundResource(R.color.colorPrimaryDark);
        }

    }

//    void downloadFile(String imageHttpAddress, ImageView imageView) {
//        URL imageUrl = null;
//        try {
//            imageUrl = new URL(imageHttpAddress);
//            HttpURLConnection conn = (HttpURLConnection) imageUrl.openConnection();
//            conn.connect();
//            Bitmap loadedImage = BitmapFactory.decodeStream(conn.getInputStream());
//            imageView.setImageBitmap(loadedImage);
//        } catch (IOException e) {
//            Toast.makeText(activity.getApplicationContext(), "Error cargando la imagen: "+e.getMessage(), Toast.LENGTH_LONG).show();
//            e.printStackTrace();
//        }
//    }


    @Override
    public int getItemCount() {
        return noticias.size();
    }
}

