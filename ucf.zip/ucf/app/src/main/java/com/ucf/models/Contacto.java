package com.ucf.models;

public class Contacto {
    public String departamento;
    public String responsable;
    public String telefono;
    public String servicio;
    public String sede;

    public Contacto( String departamento, String responsable, String telefono, String servicio, String sede) {
        this.departamento = departamento;
        this.responsable = responsable;
        this.telefono = telefono;
        this.servicio = servicio;
        this.sede = sede;
    }


}
