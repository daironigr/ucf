package com.ucf.modules.ui.ui.estudios.pregrado;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.adapters.InfoAdapter;
import com.ucf.models.Info;
import com.ucf.modules.ui.ui.somos.SomosFragment;

import java.util.ArrayList;

public class CarreraFragment extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<Info> informacion;
    private InfoAdapter adapter;

    private String carrera;
    private int FACULTAD_ID;
    private String nombre_facultad;
    private FloatingActionButton fab;

    public CarreraFragment(String carrera, int FACULTAD_ID, String nombre_facultad) {
        this.carrera = carrera;
        this.FACULTAD_ID = FACULTAD_ID;
        this.nombre_facultad = nombre_facultad;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View root = inflater.inflate(R.layout.fragment_carrera, null);
        loadInfo();
        adapter = new InfoAdapter(this.getContext(), informacion);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this.getContext());
        recyclerView = root.findViewById(R.id.lista_carrera);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        fab = root.findViewById(R.id.fab_back_to_somos);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new FacultadFragment(FACULTAD_ID, nombre_facultad)).addToBackStack(null).commit();
            }
        });

        return root;
    }

    private void loadInfo() {
        informacion = new ArrayList<>();
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_historia_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_historia_objeto));
            Info modo_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_historia_modo_actuacion));
            Info esfera = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_historia_esferas));

            this.informacion.add(objeto_estudio);
            this.informacion.add(modo_actuacion);
            this.informacion.add(esfera);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_marxismo_leninismo_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_historia_objeto));
            Info modo_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_marxismo_leninismo_modo_actuacion));

            this.informacion.add(objeto_estudio);
            this.informacion.add(modo_actuacion);
        }
        if (carrera.equals(getResources().getString(R.string.carrerra_licenciatura_educacion_artistica_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrerra_licenciatura_educacion_artistica_objeto));
            Info modo_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrerra_licenciatura_educacion_artistica_modo_actuacion));
            Info esferas = new Info("Esferas de Actuacion", getResources().getString(R.string.carrerra_licenciatura_educacion_artistica_esferas_actuacion));

            this.informacion.add(objeto_estudio);
            this.informacion.add(modo_actuacion);
            this.informacion.add(esferas);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_lenguas_extranjeras_ingles_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_lenguas_extranjeras_ingles_objeto));
            Info modo_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_lenguas_extranjeras_ingles_modo_actuacion));
            Info esferas = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_lenguas_extranjeras_ingles_esferas_actuacion));
            Info campos = new Info("Campos de Accion", getResources().getString(R.string.carrera_licenciatura_educacion_lenguas_extranjeras_ingles_campos_accion));

            this.informacion.add(objeto_estudio);
            this.informacion.add(modo_actuacion);
            this.informacion.add(esferas);
            this.informacion.add(campos);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_en_educacion_espanol_literatura_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_en_educacion_espanol_literatura_objeto));
            Info modo_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_en_educacion_espanol_literatura_modo_actuacion));
            Info esferas = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_en_educacion_espanol_literatura_esferas_actuacion));

            this.informacion.add(objeto_estudio);
            this.informacion.add(modo_actuacion);
            this.informacion.add(esferas);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_ingenieria_mecanica))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_en_educacion_mecanica))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_ingenieria_informatica))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_en_educacion_informatica))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_ingenieria_quimica))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_quimica))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_construccion))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_fisica))) {
            Info info = new Info("Objeto de Estudio", "No hay informacion definida para esta carrera");

            this.informacion.add(info);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_preescolar_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_preescolar_objeto));
            Info anyos = new Info("Años de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_preescolar_anyos_estudio));
            Info modalidad = new Info("Modalidad", getResources().getString(R.string.carrera_licenciatura_educacion_preescolar_modalidad));
            Info modo = new Info("Modo", getResources().getString(R.string.carrera_licenciatura_educacion_preescolar_modo));
            Info tipo_curso = new Info("Tipo de Curso", getResources().getString(R.string.carrera_licenciatura_educacion_preescolar_tipo_curso));

            this.informacion.add(objeto_estudio);
            this.informacion.add(anyos);
            this.informacion.add(modalidad);
            this.informacion.add(modo);
            this.informacion.add(tipo_curso);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_primaria_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_primaria_objeto));
            Info anyos = new Info("Años de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_primaria_anyos_estudio));
            Info modalidad = new Info("Modalidad", getResources().getString(R.string.carrera_licenciatura_educacion_primaria_modalidad));
            Info modo = new Info("Modo", getResources().getString(R.string.carrera_licenciatura_educacion_primaria_modo));
            Info tipo_curso = new Info("Tipo de Curso", getResources().getString(R.string.carrera_licenciatura_educacion_primaria_tipo_curso));

            this.informacion.add(objeto_estudio);
            this.informacion.add(anyos);
            this.informacion.add(modalidad);
            this.informacion.add(modo);
            this.informacion.add(tipo_curso);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_especial_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_especial_objeto));
            Info modo = new Info("Modo", getResources().getString(R.string.carrera_licenciatura_educacion_especial_modo));
            Info esferas = new Info("Esferas de actuacion", "");
            esferas.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_educacion_especial_esferas);
            this.informacion.add(objeto_estudio);
            this.informacion.add(modo);
            this.informacion.add(esferas);


        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_logopedia_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_logopedia_objeto));
            Info modo = new Info("Modo", getResources().getString(R.string.carrera_licenciatura_educacion_logopedia_modo));
            Info esferas = new Info("Esferas de actuacion", "");
            esferas.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_educacion_logopedia_esferas);
            this.informacion.add(objeto_estudio);
            this.informacion.add(modo);
            this.informacion.add(esferas);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_pedagogia_psicologia_nombre))) {
            Info objeto_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_pedagogia_psicologia_objeto));
            Info actuacion = new Info("Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_pedagogia_psicologia_actuacion));
            Info esferas = new Info("Esferas de actuacion", "");
            esferas.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_educacion_pedagogia_psicologia_esferas);
            this.informacion.add(objeto_estudio);
            this.informacion.add(actuacion);
            this.informacion.add(esferas);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_agronomia_nombre))) {
            Info modalidades = new Info("Modalidades", getResources().getString(R.string.carrera_agronomia_modalidades));
            Info tipo_cursos = new Info("Tipos de Cursos", getResources().getString(R.string.carrera_agronomia_tipos_curso));
            Info anyos = new Info("Años de estudio", getResources().getString(R.string.carrera_agronomia_anyos));
            Info objeto_profesional = new Info("Objeto profesional", getResources().getString(R.string.carrera_agronomia_objeto_profesion));
            Info objeto_trabajo = new Info("Objeto de Trabajo", getResources().getString(R.string.carrera_agronomia_objeto_trabajo));
            Info modo = new Info("Modos de Actuacion", getResources().getString(R.string.carrera_agronomia_modo_actuacion));
            Info esferas = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_agronomia_esferas));
            Info campo = new Info("Campo de Accion", "");
            campo.loadArrayFromResource(getContext(), R.array.carrera_agronomia_campos_accion);
            this.informacion.add(modalidades);
            this.informacion.add(tipo_cursos);
            this.informacion.add(anyos);
            this.informacion.add(objeto_profesional);
            this.informacion.add(objeto_trabajo);
            this.informacion.add(modo);
            this.informacion.add(esferas);
            this.informacion.add(campo);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_nombre))) {
            Info modalidades = new Info("Modalidades", getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_modalidad));
            Info Tipo_Curso = new Info("Tipo de Curso", getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_tipo_curso));
            Info Años_Estudio = new Info("Años de Estudio", getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_anyos));
            Info Objeto_Estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_objeto));
            Info Campo_Accion = new Info("Campo de Accion", getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_campo));
            Info Modos_Actuacion = new Info("Modos de Actuacion", getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_modo_actuacion));
            Info esferas = new Info("Esferas de Actuacion", "");
            esferas.loadArrayFromResource(getContext(), R.array.carrera_ingenieria_procesos_agroindustriales_esferas);
            Info funciones = new Info("Funciones", "");
            esferas.loadArrayFromResource(getContext(), R.array.carrera_ingenieria_procesos_agroindustriales_funciones);

            this.informacion.add(modalidades);
            this.informacion.add(Tipo_Curso);
            this.informacion.add(Años_Estudio);
            this.informacion.add(Objeto_Estudio);
            this.informacion.add(Campo_Accion);
            this.informacion.add(Modos_Actuacion);
            this.informacion.add(esferas);
            this.informacion.add(funciones);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_agropecuaria_nombre))) {
            Info modalidades = new Info("Modalidades", getResources().getString(R.string.carrera_licenciatura_educacion_agropecuaria_campo_accion));
            Info tipo_de_curso = new Info("Tipo de Curso", getResources().getString(R.string.carrera_licenciatura_educacion_agropecuaria_esferas));
            Info anyos = new Info("Años de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_agropecuaria_modos));
            Info funciones = new Info("Funciones", "");
            funciones.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_educacion_agropecuaria_funciones);

            this.informacion.add(modalidades);
            this.informacion.add(tipo_de_curso);
            this.informacion.add(anyos);
            this.informacion.add(funciones);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_biologia_nombre))) {
            Info modalidades = new Info("Modalidades", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_modalidad));
            Info tipos_de_curso = new Info("Tipos de Curso", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_tipos_curso));
            Info anyos = new Info("Años de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_anyos));
            Info objeto_de_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_objeto));
            Info modo_de_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_modo_actuacion));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_esferas));
            Info campo_de_accion = new Info("Campo de accion", "");
            campo_de_accion.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_educacion_biologia_campo);

            this.informacion.add(modalidades);
            this.informacion.add(tipos_de_curso);
            this.informacion.add(anyos);
            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
            this.informacion.add(esferas_de_actuacion);
            this.informacion.add(campo_de_accion);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_geografia))) {
            Info modalidades = new Info("Modalidades", getResources().getString(R.string.carrera_licenciatura_educacion_geografia_modalidad));
            Info tipo_de_curso = new Info("Tipo de curso", getResources().getString(R.string.carrera_licenciatura_educacion_geografia_tipo));
            Info anyos = new Info("Años de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_geografia_anyos));
            Info objeto_de_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_geografia_objeto));
            Info modo_de_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_geografia_modo));

            this.informacion.add(modalidades);
            this.informacion.add(tipo_de_curso);
            this.informacion.add(anyos);
            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_biologia_nombre))) {
            Info modalidades = new Info("Modalidades", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_modalidad));
            Info tipos_de_curso = new Info("Tipos de Curso", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_tipos_curso));
            Info anyos = new Info("Años de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_anyos));
            Info objeto_de_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_objeto));
            Info modo_de_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_modo_actuacion));
            Info esferas = new Info("Esferas", getResources().getString(R.string.carrera_licenciatura_educacion_biologia_esferas));
            Info campo_de_accion = new Info("Campo de accion", "");
            campo_de_accion.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_educacion_biologia_campo);

            this.informacion.add(modalidades);
            this.informacion.add(tipos_de_curso);
            this.informacion.add(anyos);
            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
            this.informacion.add(esferas);
            this.informacion.add(campo_de_accion);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_contabilidad_finanzas))) {
            Info objeto_de_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_contabilidad_finanzas_objeto));
            Info modo_de_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_contabilidad_finanzas_modo_actuacion));
            Info campos_de_accion = new Info("Campos de Accion", getResources().getString(R.string.carrera_licenciatura_contabilidad_finanzas_campos_accion));
            Info esferas = new Info("Esferas", getResources().getString(R.string.carrera_licenciatura_contabilidad_finanzas_esferas));

            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
            this.informacion.add(campos_de_accion);
            this.informacion.add(esferas);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_economia))) {
            Info objeto_de_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_economia_objeto));
            Info modo_de_actuacion = new Info("Modo de actuacion", getResources().getString(R.string.carrera_licenciatura_economia_modo));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", "");
            esferas_de_actuacion.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_economia_esferas);

            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
            this.informacion.add(esferas_de_actuacion);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_economia))) {
            Info objeto_de_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_educacion_economia_objeto));
            Info modo_de_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_economia_modo));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_economia_esferas));

            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
            this.informacion.add(esferas_de_actuacion);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_ingenieria_industrial))) {
            Info objeto_de_estudio = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_ingenieria_industrial_objeto));
            Info modo_de_actuacion = new Info("Modo de Actuacion", getResources().getString(R.string.carrera_ingenieria_industrial_modo));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_ingenieria_industrial_esferas));

            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
            this.informacion.add(esferas_de_actuacion);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_educacion_matematica))) {
            Info modalidad = new Info("Modalidad", getResources().getString(R.string.carrera_licenciatura_educacion_matematica_modalidad));
            Info tipo_de_curso = new Info("Tipo de Curso", getResources().getString(R.string.carrera_licenciatura_educacion_matematica_tipo));
            Info anyos = new Info("Años de estudio", getResources().getString(R.string.carrera_licenciatura_educacion_matematica_anyos));
            Info objeto_de_estudio = new Info("objeto_de_estudio", getResources().getString(R.string.carrera_licenciatura_educacion_matematica_objeto));
            Info modo_de_actuacion = new Info("Modo de actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_matematica_modo));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_educacion_matematica_esferas));

            this.informacion.add(modalidad);
            this.informacion.add(tipo_de_curso);
            this.informacion.add(anyos);
            this.informacion.add(objeto_de_estudio);
            this.informacion.add(modo_de_actuacion);
            this.informacion.add(esferas_de_actuacion);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_turismo))) {
            Info modalidad = new Info("Tipo de Curso", getResources().getString(R.string.carrera_licenciatura_turismo_modalidad));
            Info tipo = new Info("Años de estudio", getResources().getString(R.string.carrera_licenciatura_turismo_tipo));
            Info anyo = new Info("objeto_de_estudio", getResources().getString(R.string.carrera_licenciatura_turismo_anyo));
            Info perfil = new Info("Modo de actuacion", getResources().getString(R.string.carrera_licenciatura_turismo_perfil));
            Info campos = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_turismo_campos));
            Info esferas = new Info("Esferas de Actuacion", getResources().getString(R.string.carrera_licenciatura_turismo_esferas));

            this.informacion.add(modalidad);
            this.informacion.add(tipo);
            this.informacion.add(anyo);
            this.informacion.add(perfil);
            this.informacion.add(campos);
            this.informacion.add(esferas);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_comunicacion_social))) {
            Info objeto = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_comunicacion_social_objeto));
            Info modos = new Info("Modo de actuacion", getResources().getString(R.string.carrera_licenciatura_comunicacion_social_modos));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", "");
            esferas_de_actuacion.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_comunicacion_social_funciones);
            this.informacion.add(objeto);
            this.informacion.add(modos);
            this.informacion.add(esferas_de_actuacion);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licenciatura_esutudios_socioculturales))) {
            Info objeto = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licenciatura_esutudios_socioculturales_objeto));
            Info modos = new Info("Modo de actuacion", getResources().getString(R.string.carrera_licenciatura_esutudios_socioculturales_modo));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", "");
            esferas_de_actuacion.loadArrayFromResource(getContext(), R.array.carrera_licenciatura_esutudios_socioculturales_esferas);

            this.informacion.add(objeto);
            this.informacion.add(modos);
            this.informacion.add(esferas_de_actuacion);
        }
        if (carrera.equals(getResources().getString(R.string.carrera_licencitura_derecho))) {
            Info objeto = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_licencitura_derecho_objeto));
            Info modos = new Info("Modo de actuacion", getResources().getString(R.string.carrera_licencitura_derecho_modo));
            Info esferas_de_actuacion = new Info("Principales funciones", "");
            esferas_de_actuacion.loadArrayFromResource(getContext(), R.array.carrera_licencitura_derecho_funciones);

            this.informacion.add(objeto);
            this.informacion.add(modos);
            this.informacion.add(esferas_de_actuacion);

        }
        if (carrera.equals(getResources().getString(R.string.carrera_cultura_fisica))) {
            Info objeto = new Info("Objeto de Estudio", getResources().getString(R.string.carrera_cultura_fisica_objeto));
            Info modos = new Info("Modo de actuacion", getResources().getString(R.string.carrera_cultura_fisica_modos));
            Info esferas_de_actuacion = new Info("Esferas de Actuacion", "");
            esferas_de_actuacion.loadArrayFromResource(getContext(), R.array.carrera_cultura_fisica_esfera);

            this.informacion.add(objeto);
            this.informacion.add(modos);
            this.informacion.add(esferas_de_actuacion);
        }
    }
}
