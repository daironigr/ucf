package com.ucf.modules.ui.ui.contenidos;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.ucf.R;

public class ContenidosFragment extends Fragment implements View.OnClickListener {

    CardView libros,
            multimedia,
            clases,
            posgrado,
            editorial;
    TextView conrado,
            universidad,
            agro,
            culcomdes;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_contenidos, container, false);
        libros = root.findViewById(R.id.cv_libros);
        multimedia = root.findViewById(R.id.cv_multimedia);
        clases = root.findViewById(R.id.cv_clases);
        posgrado = root.findViewById(R.id.cv_posgrado);
        editorial = root.findViewById(R.id.cv_editorial);
        conrado = root.findViewById(R.id.txt_conrado);
        universidad = root.findViewById(R.id.txt_universidad_sociedad);
        agro = root.findViewById(R.id.txt_agro);
        culcomdes = root.findViewById(R.id.txt_cul_com_des);

        libros.setOnClickListener(this);
        multimedia.setOnClickListener(this);
        clases.setOnClickListener(this);
        posgrado.setOnClickListener(this);
        editorial.setOnClickListener(this);
        conrado.setOnClickListener(this);
        universidad.setOnClickListener(this);
        agro.setOnClickListener(this);
        culcomdes.setOnClickListener(this);


        return root;
    }

    public void onClick(View view){
        String url = "";
        switch (view.getId()){
            case R.id.cv_libros:
                url = "http://libros.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_multimedia:
                url = "http://youtube.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_clases:
                url = "http://clasesvirtuales.ucf.edu.cu/login";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_posgrado:
                url = "https://postgradosvirtuales.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_editorial:
                url = "https://universosur.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.txt_conrado:
                url = "https://conrado.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.txt_universidad_sociedad:
                url = "https://rus.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.txt_agro:
                url = "https://aes.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.txt_cul_com_des:
                url = "https://rccd.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;

        }
    }
}