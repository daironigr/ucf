package com.ucf.modules.ui.ui.editorialuniverso;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.modules.ui.ui.somos.SomosFragment;

public class EUniversoFragment extends Fragment {
    private FloatingActionButton fab;
    private TextView txt_link_editorial, txt_link_catedra;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View root = inflater.inflate(R.layout.fragment_editorial_universo, null);
        txt_link_editorial = root.findViewById(R.id.txt_link_editorial);
        txt_link_catedra = root.findViewById(R.id.txt_link_catedra);
        fab = root.findViewById(R.id.fab_back_to_somos);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new SomosFragment()).addToBackStack(null).commit();
            }
        });
        txt_link_catedra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://intranet.ucf.edu.cu/?page_id=524";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
            }
        });
        txt_link_editorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://universosur.ucf.edu.cu/index.php/en/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
            }
        });

        return root;
    }
}
