package com.ucf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.VideoView;

public class SplashActivity extends AppCompatActivity {
    ImageView escudo, castillo, libro, paloma;
    VideoView splash;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        splash = (VideoView) findViewById(R.id.splash);
        String path = "android.resource://" + getPackageName() + "/" + R.raw.splash_ii;
        splash.setVideoURI(Uri.parse(path));
        splash.start();

        splash.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                finish();
            }
        });


    }



}
