package com.ucf.modules.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.MainActivity;
import com.ucf.R;
import com.ucf.adapters.GalleryAdapter;
import com.ucf.gallerylayoutmanager.GalleryLayoutManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class GaleriaActivity extends AppCompatActivity {
    private GridView grid;
    private GalleryAdapter adapter;
    private GalleryLayoutManager galleryLayoutManager;
    private RecyclerView recyclerView;
    private ArrayList<Integer> images;
    private TextView img_number, pie;
    FloatingActionButton floatingActionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_galeria);
        initList();
        img_number = findViewById(R.id.img_number);
        pie = findViewById(R.id.pie);
        recyclerView = findViewById(R.id.mRecyclerView);
        galleryLayoutManager = new GalleryLayoutManager(GalleryLayoutManager.HORIZONTAL);
        galleryLayoutManager.attach(recyclerView, 0);
//        floatingActionButton = findViewById(R.id.floatingActionButton2);
        recyclerView.setAdapter(new GalleryAdapter(this, images));

        galleryLayoutManager.setItemTransformer(new ScaleTransformer());

        galleryLayoutManager.setOnItemSelectedListener(new GalleryLayoutManager.OnItemSelectedListener() {
            @Override
            public void onItemSelected(RecyclerView recyclerView, View item, int position) {
                img_number.setText(""+(galleryLayoutManager.getCurSelectedPosition()+1)+" / "+ images.size());
                pie.setText("Pie de foto "+ position);
            }
        });

//        calculateLeftConstraint(floatingActionButton);

    }
    public class ScaleTransformer implements GalleryLayoutManager.ItemTransformer {

        @Override
        public void transformItem(GalleryLayoutManager layoutManager, View item, float fraction) {
            item.setPivotX(item.getWidth() / 1.8f);
            item.setPivotY(item.getHeight()/1.8f);
            float scale = 1 - 0.8f * Math.abs(fraction);
            item.setScaleX(scale);
            item.setScaleY(scale);
        }

    }
    private void initList(){
        this.images = new ArrayList<>();
        images.add(R.drawable.pic_one);
        images.add(R.drawable.pic_two);
        images.add(R.drawable.pic_three);
        images.add(R.drawable.pic_four);
        images.add(R.drawable.pic_five);
        images.add(R.drawable.pic_six);
        images.add(R.drawable.pic_seven);
        images.add(R.drawable.pic_eight);
        images.add(R.drawable.pic_nine);
        images.add(R.drawable.pic_ten);
        images.add(R.drawable.pic_eleven);


    }

    public void back(View view){
        startActivity(new Intent(GaleriaActivity.this, MainActivity.class));
        this.finish();
    }

//    private void calculateLeftConstraint(View v){
//        int screen_width = getWindow().getWindowManager().getDefaultDisplay().getWidth();
//        int view_width = v.getWidth();
//        int left_constraint = screen_width - view_width;
//        ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(v.getWidth(), v.getHeight());
//        layoutParams.setMarginStart(left_constraint);
//        v.setLayoutParams(layoutParams);
//    }


}
