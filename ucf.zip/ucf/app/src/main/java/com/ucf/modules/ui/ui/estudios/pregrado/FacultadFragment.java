package com.ucf.modules.ui.ui.estudios.pregrado;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.adapters.CarreraAdapter;
import com.ucf.models.Consejo;
import com.ucf.modules.ui.ui.somos.SomosFragment;
import com.ucf.utils.SQLHelper;

import java.util.ArrayList;

public class FacultadFragment extends Fragment {

    private int FACULTAD_ID;
    private ArrayList<String> carreras;
    private RecyclerView lista;
    private CarreraAdapter adapter;
    private Consejo decano;
    private SQLHelper database;
    private String telefono;
    private TextView txt_nombre_facultad, txt_nombre_decano, txt_correo_decano, txt_telefono_primario, txt_telefono_secundario;
    ImageView avatar_decano;
    private String nombre_facultad;
    private FloatingActionButton fab;

    public FacultadFragment(int FACULTAD_ID, String nombre_facultad) {
        this.FACULTAD_ID = FACULTAD_ID;
        this.nombre_facultad = nombre_facultad;

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        database = new SQLHelper(this.getContext());
        carreras = new ArrayList<>();
        loadCarreras();
        adapter = new CarreraAdapter(this.getContext(), carreras, getFragmentManager(), this.FACULTAD_ID, this.nombre_facultad);

        View root = inflater.inflate(R.layout.fragment_facultad, null);
        lista = root.findViewById(R.id.carreras);
        fab = root.findViewById(R.id.fab_back_to_somos);
        txt_nombre_facultad = root.findViewById(R.id.txt_nombre_facultad);
        txt_nombre_decano = root.findViewById(R.id.txt_nombre_decano);
        txt_correo_decano = root.findViewById(R.id.txt_correo_decano);
        txt_telefono_primario = root.findViewById(R.id.txt_telefono_primario);
        txt_telefono_secundario = root.findViewById(R.id.txt_telefono_secundario);
        avatar_decano = root.findViewById(R.id.img_decano);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this.getContext());
        lista.setLayoutManager(layoutManager);
        lista.setAdapter(adapter);

        loadInfo();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new PregradoFragment()).addToBackStack(null).commit();
            }
        });
        return root;
    }

    private void loadInfo(){
        txt_nombre_facultad.setText(nombre_facultad);
        txt_nombre_decano.setText(decano.nombre);
        txt_correo_decano.setText(decano.correo);
        txt_telefono_primario.setText(telefono);
        txt_telefono_secundario.setText("");
        avatar_decano.setImageBitmap(decano.getImageBmp());
    }
    private void loadCarreras() {
        try {
            database.open();
        } catch (Exception e) {
            e.printStackTrace();
        }
        switch (this.FACULTAD_ID) {
            case R.id.cv_f_humanidades:
                this.decano = database.getDecano(17);
                database.close();
                this.telefono = "+5343513612 ext. 108";
                carreras.add(getResources().getString(R.string.carrera_licenciatura_historia_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_marxismo_leninismo_nombre));
                carreras.add(getResources().getString(R.string.carrerra_licenciatura_educacion_artistica_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_lenguas_extranjeras_ingles_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_en_educacion_espanol_literatura_nombre));
                break;
            case R.id.cv_f_ingenieria:
                this.decano = database.getDecano(18);
                database.close();
                this.telefono = "43 500133";
                carreras.add(getResources().getString(R.string.carrera_ingenieria_mecanica));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_en_educacion_mecanica));
                carreras.add(getResources().getString(R.string.carrera_ingenieria_informatica));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_en_educacion_informatica));
                carreras.add(getResources().getString(R.string.carrera_ingenieria_quimica));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_quimica));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_construccion));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_fisica));
                break;
            case R.id.cv_f_educacion:
                this.decano = database.getDecano(19);
                database.close();
                this.telefono = "43 513612 ext. 107";
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_preescolar_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_primaria_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_especial_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_logopedia_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_pedagogia_psicologia_nombre));
                break;
            case R.id.cv_f_ciencias_agrarias:
                this.decano = database.getDecano(15);
                database.close();
                this.telefono = "43 500136";
                carreras.add(getResources().getString(R.string.carrera_agronomia_nombre));
                carreras.add(getResources().getString(R.string.carrera_ingenieria_procesos_agroindustriales_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_agropecuaria_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_biologia_nombre));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_geografia));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_biologia_nombre));
                break;
            case R.id.cv_f_cee:
                this.decano = database.getDecano(14);
                database.close();
                this.telefono = "43 500134";
                carreras.add(getResources().getString(R.string.carrera_licenciatura_contabilidad_finanzas));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_economia));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_economia));
                carreras.add(getResources().getString(R.string.carrera_ingenieria_industrial));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_educacion_matematica));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_turismo));
                break;
            case R.id.cv_f_cs:
                this.decano = database.getDecano(16);
                database.close();
                this.telefono = "43 500135";
                carreras.add(getResources().getString(R.string.carrera_licenciatura_comunicacion_social));
                carreras.add(getResources().getString(R.string.carrera_licenciatura_esutudios_socioculturales));
                carreras.add(getResources().getString(R.string.carrera_licencitura_derecho));
                break;
            case R.id.cv_f_cfd:
                this.decano = database.getDecano(13);
                database.close();
                this.telefono = "43 500206";
                carreras.add(getResources().getString(R.string.carrera_cultura_fisica));
                break;

        }
    }
}
