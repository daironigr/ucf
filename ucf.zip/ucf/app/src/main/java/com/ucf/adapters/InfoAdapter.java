package com.ucf.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ucf.R;
import com.ucf.models.Info;

import java.util.ArrayList;

public class InfoAdapter extends RecyclerView.Adapter<InfoAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<Info> informacion;

    public InfoAdapter(Context context, ArrayList<Info> informacion) {
        this.context = context;
        this.informacion = informacion;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sub_item_carrera, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Info info = informacion.get(position);
        holder.txt_titulo.setText(info.titulo);
        holder.txt_contenido.setText(info.info);
        if(info.info_array.length > 0){
            LinearLayout ll_sub_item_carrera = holder.itemView.findViewById(R.id.ll_sub_item_carrera);
            for(String s : info.info_array){
                TextView tv = new TextView(context);
                tv.setTextColor(context.getResources().getColor(android.R.color.white));
                tv.setText(s);
                ll_sub_item_carrera.addView(tv);
            }
        }
        holder.itemView.setBackgroundColor(context.getResources().getColor((position % 2 == 0) ? R.color.colorAccent : R.color.colorPrimaryDark));
    }

    @Override
    public int getItemCount() {
        return this.informacion.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txt_titulo, txt_contenido;

        public MyViewHolder(View view) {
            super(view);
            txt_titulo = view.findViewById(R.id.txt_titulo);
            txt_contenido = view.findViewById(R.id.txt_contenido);

        }
    }


}
