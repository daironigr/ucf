package com.ucf.modules.ui.ui.gallery;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.load.model.ResourceLoader;
import com.ucf.R;
import com.ucf.adapters.GalleryAdapter;
import com.ucf.gallerylayoutmanager.GalleryLayoutManager;
import com.ucf.modules.ui.GaleriaActivity;
import com.veinhorn.scrollgalleryview.ScrollGalleryView;
import com.veinhorn.scrollgalleryview.builder.GallerySettings;

import java.util.ArrayList;
import static com.veinhorn.scrollgalleryview.loader.picasso.dsl.DSL.*;
public class GalleryFragment extends Fragment {

    private GridView grid;
    private GalleryAdapter adapter;
    private GalleryLayoutManager galleryLayoutManager;
    private RecyclerView recyclerView;
    private ArrayList<Integer> images;
    private TextView img_number, pie;

    private ScrollGalleryView galleryView;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        initList();
//        img_number = root.findViewById(R.id.img_number);
        pie = root.findViewById(R.id.pie);
        recyclerView = root.findViewById(R.id.mRecyclerView);
        galleryLayoutManager = new GalleryLayoutManager(GalleryLayoutManager.HORIZONTAL);
        galleryLayoutManager.attach(recyclerView, 0);
//        floatingActionButton = findViewById(R.id.floatingActionButton2);
        recyclerView.setAdapter(new GalleryAdapter(this.getContext(), images));

        galleryLayoutManager.setItemTransformer(new ScaleTransformer());
        final String[] img_footer = getResources().getStringArray(R.array.images_footer);
        galleryLayoutManager.setOnItemSelectedListener(new GalleryLayoutManager.OnItemSelectedListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemSelected(RecyclerView recyclerView, View item, int position) {
//                img_number.setText(""+(galleryLayoutManager.getCurSelectedPosition()+1)+" / "+ images.size());
                pie.setText(img_footer[position]);
            }
        });
        return root;
    }

    public class ScaleTransformer implements GalleryLayoutManager.ItemTransformer {

        @Override
        public void transformItem(GalleryLayoutManager layoutManager, View item, float fraction) {
            item.setPivotX(item.getWidth() / 1.8f);
            item.setPivotY(item.getHeight()/1.8f);
            float scale = 1 - 0.8f * Math.abs(fraction);
            item.setScaleX(scale);
            item.setScaleY(scale);
        }

    }
    private void initList(){
        this.images = new ArrayList<>();
        images.add(R.drawable.pic_one);
        images.add(R.drawable.pic_two);
        images.add(R.drawable.pic_three);
        images.add(R.drawable.pic_four);
        images.add(R.drawable.pic_five);
        images.add(R.drawable.pic_six);
        images.add(R.drawable.pic_seven);
        images.add(R.drawable.pic_eight);
        images.add(R.drawable.pic_nine);
        images.add(R.drawable.pic_ten);
        images.add(R.drawable.pic_eleven);


    }
}