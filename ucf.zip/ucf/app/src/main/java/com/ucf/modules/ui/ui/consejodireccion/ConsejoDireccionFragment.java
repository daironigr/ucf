package com.ucf.modules.ui.ui.consejodireccion;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.adapters.ConsejoDireccionAdapter;
import com.ucf.models.Consejo;
import com.ucf.modules.ui.ui.somos.SomosFragment;
import com.ucf.utils.SQLHelper;

import java.util.ArrayList;

public class ConsejoDireccionFragment extends Fragment {
    private RecyclerView lista;
    private ArrayList<Consejo> consejo_direccion;
    private SQLHelper database;
    private ConsejoDireccionAdapter adapter;
    private FloatingActionButton fab;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        consejo_direccion = new ArrayList<>();
        database = new SQLHelper(this.getContext());
        try{
            database.open();
            consejo_direccion = database.getConsejo();
            database.close();
        }catch (Exception e){
            Toast.makeText(this.getContext(), "Ha ocurrido un error con la base de datos", Toast.LENGTH_SHORT).show();
        }
        adapter = new ConsejoDireccionAdapter(consejo_direccion, getContext());
        View root = inflater.inflate(R.layout.fragment_consejo, null);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext().getApplicationContext());
        fab = root.findViewById(R.id.fab_back_to_somos);
        lista = root.findViewById(R.id.lista_consejo_direccion);
        lista.setLayoutManager(layoutManager);
        lista.setAdapter(adapter);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new SomosFragment()).addToBackStack(null).commit();
            }
        });
        return root;
    }
}
