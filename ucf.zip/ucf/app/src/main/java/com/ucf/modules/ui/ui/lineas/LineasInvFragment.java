package com.ucf.modules.ui.ui.lineas;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.modules.ui.ui.somos.SomosFragment;

public class LineasInvFragment extends Fragment {
    private TextView txt_lineas;
    private String[] lineas;
    private LinearLayout ll_lineas;
    private FloatingActionButton fab;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View root = inflater.inflate(R.layout.fragment_lineas, null);
        lineas = getResources().getStringArray(R.array.lineas_investigacion);
        ll_lineas = root.findViewById(R.id.ll_lineas);
        txt_lineas = root.findViewById(R.id.txt_lineas);
        fab = root.findViewById(R.id.fab_back_to_somos);
        for(int i=0; i<lineas.length; i++){
            TextView linea = new TextView(getContext());
            linea.setText(lineas[i]);
            linea.setTextColor(getResources().getColor(android.R.color.white));
            ll_lineas.addView(linea);
        }

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new SomosFragment()).addToBackStack(null).commit();
            }
        });
        return root;
    }
}
