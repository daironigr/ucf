package com.ucf.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.ucf.R;
import com.ucf.models.Consejo;

import java.util.ArrayList;

public class ConsejoCientificoAdapter extends RecyclerView.Adapter<ConsejoCientificoAdapter.MyViewHolder> {
    private ArrayList<String> consejo_cientifico = new ArrayList<>();
    private Context context;

    public ConsejoCientificoAdapter(ArrayList<String> consejo_cientifico,Context context) {
        this.consejo_cientifico = consejo_cientifico;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView nombre, correo, cargo;

        public MyViewHolder(View view) {
            super(view);
            nombre = view.findViewById(R.id.txt_persona_nombre);
            correo = view.findViewById(R.id.txt_persona_correo);
            cargo = view.findViewById(R.id.txt_persona_cargo);


        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_persona, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public int getItemCount() {
        return consejo_cientifico.size();
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final String[] persona = consejo_cientifico.get(position).split(";");
        holder.nombre.setText(persona[1]);
        holder.correo.setText("");
        holder.cargo.setText(persona[0]);
        holder.itemView.setBackgroundColor(context.getResources().getColor((position % 2 == 0) ? R.color.colorAccent : R.color.colorPrimaryDark));

    }
}
