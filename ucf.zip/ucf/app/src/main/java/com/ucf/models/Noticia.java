package com.ucf.models;

public class Noticia {
    public String titulo;
    public String resumen;
    public String link;
    public String link_img;
    public String tipo;
    public int img_res;
    public Noticia(String titulo, String resumen, String link, String link_img, String tipo) {
        this.titulo = titulo;
        this.resumen = resumen;
        this.link = link;
        this.link_img = link_img;
        this.tipo = tipo;
        this.img_res = -1;
    }

    public void setRes(int img_res){
        this.img_res = img_res;
    }
}
