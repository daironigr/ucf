package com.ucf.modules.ui.ui.estudios.pregrado;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SurfaceControl;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.ucf.R;

public class PregradoFragment extends Fragment implements View.OnClickListener{
    CardView cv_f_humanidades,
    cv_f_ingenieria,
    cv_f_educacion,
    cv_f_ciencias_agrarias,
    cv_f_cee,
    cv_f_cs,
    cv_f_cfd;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View root = inflater.inflate(R.layout.fragment_pregrado, null);

        cv_f_humanidades = root.findViewById(R.id.cv_f_humanidades);
        cv_f_ingenieria = root.findViewById(R.id.cv_f_ingenieria);
        cv_f_educacion = root.findViewById(R.id.cv_f_educacion);
        cv_f_ciencias_agrarias = root.findViewById(R.id.cv_f_ciencias_agrarias);
        cv_f_cee = root.findViewById(R.id.cv_f_cee);
        cv_f_cs = root.findViewById(R.id.cv_f_cs);
        cv_f_cfd = root.findViewById(R.id.cv_f_cfd);

        cv_f_humanidades.setOnClickListener(this);
        cv_f_ingenieria.setOnClickListener(this);
        cv_f_educacion.setOnClickListener(this);
        cv_f_ciencias_agrarias.setOnClickListener(this);
        cv_f_cee.setOnClickListener(this);
        cv_f_cs.setOnClickListener(this);
        cv_f_cfd.setOnClickListener(this);

        return root;
    }


    public void onClick(View v) {
        int id = v.getId();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        switch (id) {
            case R.id.cv_f_humanidades:
                fragmentTransaction.replace(R.id.container_body, new FacultadFragment(id, "Facultad de Humanidades")).addToBackStack(null).commit();
                break;
            case R.id.cv_f_ingenieria:
                fragmentTransaction.replace(R.id.container_body, new FacultadFragment(id, "Facultad de Ingenieria")).addToBackStack(null).commit();
                break;
            case R.id.cv_f_educacion:
                fragmentTransaction.replace(R.id.container_body, new FacultadFragment(id, "Facultad de Educacion")).addToBackStack(null).commit();
                break;
            case R.id.cv_f_ciencias_agrarias:
                fragmentTransaction.replace(R.id.container_body, new FacultadFragment(id, "Facultad de Ciencias Agrarias")).addToBackStack(null).commit();
                break;
            case R.id.cv_f_cee:
                fragmentTransaction.replace(R.id.container_body, new FacultadFragment(id, "Facultad de Ciencias Economicas y Empresariales")).addToBackStack(null).commit();
                break;
            case R.id.cv_f_cs:
                fragmentTransaction.replace(R.id.container_body, new FacultadFragment(id, "Facultad de Ciencias Sociales")).addToBackStack(null).commit();
                break;
            case R.id.cv_f_cfd:
                fragmentTransaction.replace(R.id.container_body, new FacultadFragment(id, "Facultad de Cultura Fisica y el Deporte")).addToBackStack(null).commit();
                break;

        }

    }
}
