package com.ucf.utils;

import android.app.Activity;
import android.content.Context;

import androidx.core.app.ActivityCompat;

public class Permission {

    public static final String P_READ_EXTERNAL_STORAGE = "android.permission.READ_EXTERNAL_STORAGE";
    public static final String EXTERNAL = "android.permission.WRITE_EXTERNAL_STORAGE";
    public static final String P_CALL_PHONE = "android.permission.CALL_PHONE";
    public static final String P_INTERNET = "android.permission.INTERNET";
    public static final String P_NETWORK_STATE = "android.permission.ACCESS_NETWORK_STATE";

    public static boolean checkPermissions(Context context) {
        return ActivityCompat.checkSelfPermission(context, P_READ_EXTERNAL_STORAGE) == 0 &&
                ActivityCompat.checkSelfPermission(context, P_CALL_PHONE) == 0 &&
                ActivityCompat.checkSelfPermission(context, P_INTERNET) == 0 &&
                ActivityCompat.checkSelfPermission(context, P_NETWORK_STATE) == 0 &&
                ActivityCompat.checkSelfPermission(context, EXTERNAL) == 0;
    }

    public static boolean checkPermission(Context context, String permission) {
        return ActivityCompat.checkSelfPermission(context, permission) == 0;
    }

    public static void requestPermissions(Activity activity) {
        ActivityCompat.requestPermissions(activity, new String[]{
                P_READ_EXTERNAL_STORAGE,
                EXTERNAL,
                P_CALL_PHONE,
                P_NETWORK_STATE,
                P_INTERNET,

        }, 1);
    }

    public static void requestPermission(Activity activity, String permission) {
        ActivityCompat.requestPermissions(activity, new String[]{permission}, 1);
    }


}