package com.ucf.models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class Consejo {
    public String cargo;
    public String nombre;
    public String correo;
    public byte[] byte_array;

    public Consejo(String cargo, String nombre, String correo, byte[] byte_array) {
        this.cargo = cargo;
        this.nombre = nombre;
        this.correo = correo;
        this.byte_array = byte_array;
    }

    public Bitmap getImageBmp(){
        return BitmapFactory.decodeByteArray(this.byte_array, 0, this.byte_array.length);
    }
}
