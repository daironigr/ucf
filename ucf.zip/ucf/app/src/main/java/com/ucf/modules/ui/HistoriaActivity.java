package com.ucf.modules.ui;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;
import com.ucf.R;
import com.ucf.models.Etapa;
import com.ucf.modules.ui.ui.home.HomeFragment;
import com.ucf.utils.SQLHelper;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;

public class HistoriaActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    DrawerLayout drawer;

    private static Fragment fragment;
    private static FragmentTransaction fragmentTransaction;
    private static String title;
    private static boolean viewIsAtHome;
    private final FragmentManager fragmentManager = getSupportFragmentManager();
    NavigationView navigationView;
    SQLHelper db;
    Etapa etapa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historia);
//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
        drawer = findViewById(R.id.drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow,
                R.id.nav_tools, R.id.nav_share, R.id.nav_send)
                .setDrawerLayout(drawer)
                .build();
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
//        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
//        NavigationUI.setupWithNavController(navigationView, navController);
//        db = new SQLHelper(this);
//        etapa = new Etapa("", "");
//        try{
//            db.open();
//            etapa = db.getEtapa(11);
//            db.close();
//        }catch (Exception e){}
//        fragment = new HomeFragment(etapa);
//        title = "Inicio";
//        if (fragment != null) {
//            fragmentTransaction = this.fragmentManager.beginTransaction();
//            fragmentTransaction.replace(R.id.container_body, fragment).commit();
//            if (getSupportActionBar() != null) {
//                getSupportActionBar().setTitle(title);
//            }
//        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.historia, menu);
        return false;
    }

//    @Override
//    public boolean onSupportNavigateUp() {
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
//        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
//                || super.onSupportNavigateUp();
//    }

    public boolean onNavigationItemSelected(MenuItem item) {
        drawer.closeDrawer(GravityCompat.START);

        showFragment(item.getItemId());

        return true;
    }

    public void showFragment(int id) {
//        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//        getSupportFragmentManager().popBackStack();
//
//        if (fragment != null) {
//            transaction.remove(fragment);
//            transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE);
//            transaction.commit();
//        }
//        Etapa etapa = new Etapa("", "");
//
//        try {
//            db.open();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//        switch (id) {
//            case R.id.nav_etapa_1:
//                etapa = db.getEtapa(1);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_2:
//                etapa = db.getEtapa(2);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_3:
//                etapa = db.getEtapa(3);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_4:
//                etapa = db.getEtapa(4);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_5:
//                etapa = db.getEtapa(5);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_6:
//                etapa = db.getEtapa(6);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_7:
//                etapa = db.getEtapa(7);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_8:
//                etapa = db.getEtapa(8);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_9:
//                etapa = db.getEtapa(9);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//            case R.id.nav_etapa_10:
//                etapa = db.getEtapa(10);
//                db.close();
//                fragment = new HomeFragment(etapa);
//                break;
//
//        }
//        fragmentTransaction = this.fragmentManager.beginTransaction();
//        fragmentTransaction.replace(R.id.container_body, fragment).commit();
//        if (getSupportActionBar() != null) {
//            getSupportActionBar().setTitle(title);
//        }

    }
}
