package com.ucf.adapters;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.ucf.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.ViewHolder> {
   private List<Integer> images;
   private LayoutInflater inflater;
    private Context context;

    public GalleryAdapter(Context context, List<Integer> images) {
        this.inflater = LayoutInflater.from(context);
        this.images = images;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = inflater.inflate(R.layout.item_galeria, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position){
        Integer image = images.get(position);
        holder.pic.setImageResource(image);
        holder.pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog dialog = new AlertDialog.Builder(context)
                        .setMessage("Quieres exportar esta imagen?")
                        .setIcon(R.drawable.icon)
                        .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                saveImage(position);
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                                dialog.dismiss();
                            }
                        })
                        .show();

            }
        });
//        holder.pie.setText("Pie de foto img" + position);
    }

    @Override
    public int getItemCount(){
        return images.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        ImageView pic;
//        TextView pie;
        ViewHolder(View itemView){
            super(itemView);
            pic = itemView.findViewById(R.id.item_galeria);
//            pie = itemView.findViewById(R.id.pie_foto);
        }


    }
    Integer getItem(int id){
        return images.get(id);
    }

    public void saveImage(int pos){
//        try{
            String ExternalStorageDirectory = Environment.getExternalStorageDirectory() + File.separator;
            String path = "ucfgallery/";
            String nombre = String.valueOf(pos)+ ".png";
            File ucfDirectory = new File(ExternalStorageDirectory + path);
            if(!ucfDirectory.exists()){
                ucfDirectory.mkdirs();
            }
//
//            Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), images.get(pos));
//
            File finalPath = new File(ExternalStorageDirectory + path + nombre);
//
//            ContentValues values = new ContentValues();
//            values.put(MediaStore.Images.Media.TITLE, "ucf_image_"+(pos+1));
//            values.put(MediaStore.Images.Media.DESCRIPTION, "Imagen de la galeria historica de la UCF");
//            values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
//            values.put(MediaStore.Images.ImageColumns.BUCKET_ID, finalPath.toString().toLowerCase(Locale.getDefault()).hashCode());
//            values.put(MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME, finalPath.toString().toLowerCase(Locale.getDefault()));
//            values.put("_data", finalPath.getAbsolutePath());
//            ContentResolver cr = context.getContentResolver();
//            cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
//
//        }catch(Exception e){
//            Log.e("ERROR", e.getMessage());
//        }
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), images.get(pos));
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        try{
            FileOutputStream outputStream = new FileOutputStream(finalPath);
            outputStream.write(byteArray);
            outputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
