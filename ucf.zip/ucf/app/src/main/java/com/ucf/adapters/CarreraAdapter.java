package com.ucf.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.ucf.R;
import com.ucf.models.Consejo;
import com.ucf.modules.ui.ui.estudios.pregrado.CarreraFragment;

import java.util.ArrayList;

import static com.ucf.utils.Utiles.enviar;

public class CarreraAdapter extends RecyclerView.Adapter<CarreraAdapter.MyViewHolder>{
    private Context context;
    private ArrayList<String> carreras;
    private FragmentManager fragmentManager;
    private int FACULTAD_ID;
    private String nombre_facultad;
    public CarreraAdapter(Context context, ArrayList<String> carreras, FragmentManager fragmentManager, int FACULTAD_ID, String nombre_facultad) {
        this.context = context;
        this.carreras = carreras;
        this.fragmentManager = fragmentManager;
        this.nombre_facultad = nombre_facultad;
        this.FACULTAD_ID = FACULTAD_ID;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView nombre;
        public ImageView img;

        public MyViewHolder(View view) {
            super(view);
            nombre = view.findViewById(R.id.txt_nombre_carrera);

        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_carrera, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final String carrera = carreras.get(position);
        holder.nombre.setText(carrera);
        holder.itemView.setBackgroundColor(context.getResources().getColor((position % 2 == 0) ? R.color.colorAccent : R.color.colorPrimaryDark));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, carrera, Toast.LENGTH_SHORT).show();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.container_body, new CarreraFragment(carrera, FACULTAD_ID, nombre_facultad)).commit();
            }
        });
    }

    @Override
    public int getItemCount() {
        return carreras.size();
    }


}
