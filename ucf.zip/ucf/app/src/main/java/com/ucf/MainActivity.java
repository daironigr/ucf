package com.ucf;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.etiennelawlor.imagegallery.library.activities.ImageGalleryActivity;
import com.nightonke.boommenu.BoomButtons.BoomButton;
import com.nightonke.boommenu.BoomButtons.ButtonPlaceEnum;
import com.nightonke.boommenu.BoomButtons.OnBMClickListener;
import com.nightonke.boommenu.BoomButtons.SimpleCircleButton;
import com.nightonke.boommenu.BoomMenuButton;
import com.nightonke.boommenu.Piece.PiecePlaceEnum;
import com.ucf.models.Etapa;
import com.ucf.modules.ui.GaleriaActivity;
import com.ucf.modules.ui.HistoriaActivity;
import com.ucf.modules.ui.UtilesActivity;
import com.ucf.modules.ui.ui.contenidos.ContenidosFragment;
import com.ucf.modules.ui.ui.gallery.GalleryFragment;
import com.ucf.modules.ui.ui.home.HomeFragment;
import com.ucf.modules.ui.ui.slideshow.DirectorioFragment;
import com.ucf.modules.ui.ui.somos.SomosFragment;
import com.ucf.modules.ui.ui.story.StoryFragment;
import com.ucf.modules.ui.ui.tools.ToolsFragment;
import com.ucf.utils.Permission;
import com.ucf.utils.SQLHelper;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    BoomMenuButton bmb;
    private static Fragment fragment;
    private static FragmentTransaction fragmentTransaction;
    private final FragmentManager fragmentManager = getSupportFragmentManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!Permission.checkPermissions(this)) {
            Permission.requestPermissions(this);
        }
        bmb = (BoomMenuButton) findViewById(R.id.bmb);
        bmb.setPiecePlaceEnum(PiecePlaceEnum.DOT_7_2);
        bmb.setButtonPlaceEnum(ButtonPlaceEnum.SC_7_2);
        bmb.setNormalColor(R.color.colorPrimaryDark);
        bmb.setHighlightedColor(R.color.colorPrimaryDark);


        for (int i = 0; i < bmb.getButtonPlaceEnum().buttonNumber(); i++) {
            switch (i) {
                case 0:
                    SimpleCircleButton.Builder builder_home = new SimpleCircleButton.Builder()
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    showFragment(index);
                                }
                            });
                    builder_home.normalColorRes(R.color.colorPrimary);
                    builder_home.highlightedColorRes(R.color.colorPrimary);
                    builder_home.normalImageRes(R.drawable.icon);
                    bmb.addBuilder(builder_home);
                    break;
                case 1:
                    SimpleCircleButton.Builder builder_h = new SimpleCircleButton.Builder()
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
//                                    startActivity(new Intent(MainActivity.this, HistoriaActivity.class));
                                    showFragment(index);
                                }
                            });
                    builder_h.normalColorRes(R.color.colorAccent);
                    builder_h.highlightedColorRes(R.color.colorAccent);
                    builder_h.normalImageRes(R.drawable.ic_h_square);
                    bmb.addBuilder(builder_h);
                    break;
                case 2:
                    SimpleCircleButton.Builder builder_g = new SimpleCircleButton.Builder()
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    showFragment(index);
                                }
                            });
                    builder_g.normalColorRes(R.color.colorAccent);
                    builder_g.highlightedColorRes(R.color.colorAccent);
                    builder_g.normalImageRes(R.drawable.ic_images);
                    bmb.addBuilder(builder_g);
                    break;
                case 3:
                    SimpleCircleButton.Builder builder_u = new SimpleCircleButton.Builder()
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    showFragment(index);
                                }
                            });
                    builder_u.normalColorRes(R.color.colorAccent);
                    builder_u.highlightedColorRes(R.color.colorAccent);
                    builder_u.normalImageRes(R.drawable.ic_wrench);
                    bmb.addBuilder(builder_u);
                    break;
                case 4:
                    SimpleCircleButton.Builder builder_c = new SimpleCircleButton.Builder()
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    showFragment(index);
                                }
                            });
                    builder_c.normalColorRes(R.color.colorAccent);
                    builder_c.highlightedColorRes(R.color.colorAccent);
                    builder_c.normalImageRes(R.drawable.ic_grip_horizontal);
                    bmb.addBuilder(builder_c);
                    break;
                case 5:
                    SimpleCircleButton.Builder builder_d = new SimpleCircleButton.Builder()
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    showFragment(index);
                                }
                            });
                    builder_d.normalColorRes(R.color.colorAccent);
                    builder_d.highlightedColorRes(R.color.colorAccent);
                    builder_d.normalImageRes(R.drawable.ic_address_card);
                    bmb.addBuilder(builder_d);
                    break;
                case 6:
                    SimpleCircleButton.Builder builder_somos = new SimpleCircleButton.Builder()
                            .listener(new OnBMClickListener() {
                                @Override
                                public void onBoomButtonClick(int index) {
                                    showFragment(index);
                                }
                            });
                    builder_somos.normalColorRes(R.color.colorAccent);
                    builder_somos.highlightedColorRes(R.color.colorAccent);
                    builder_somos.normalImageRes(R.drawable.ic_question_circle);
                    bmb.addBuilder(builder_somos);
                    break;
                default:
                    bmb.addBuilder(new SimpleCircleButton.Builder()
                            .normalImageRes(R.drawable.icon));
            }

        }

        fragment = new HomeFragment(this);
        if (fragment != null) {
            fragmentTransaction = this.fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container_body, fragment).commit();
        }

    }

    public void onClick(View v) {
        switch (v.getId()) {
//            case R.id.cv_historia:
//                startActivity(new Intent(MainActivity.this, HistoriaActivity.class));
//                break;
//            case R.id.cv_contenido:
//
//                break;
//            case R.id.cv_utiles:
//                startActivity(new Intent(MainActivity.this, UtilesActivity.class));
//                break;
//            case R.id.cv_galeria:
//                startActivity(new Intent(MainActivity.this, GaleriaActivity.class));
//                break;

        }
    }

    public void showFragment(int id) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        getSupportFragmentManager().popBackStack();

        if (fragment != null) {
            transaction.remove(fragment);
            transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE);
            transaction.commit();
        }


        switch (id) {
            case 0:
                fragment = new HomeFragment(this);
                break;
            case 1:
                fragment = new StoryFragment();
                break;
            case 2:
                fragment = new GalleryFragment();
                break;
            case 3:
                fragment = new ToolsFragment();
                break;
            case 4:
                fragment = new ContenidosFragment();
                break;
            case 5:
                fragment = new DirectorioFragment();
                break;
            case 6:
                fragment = new SomosFragment();
                break;



        }
        fragmentTransaction = this.fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container_body, fragment).commit();
//        if (getSupportActionBar() != null) {
//            getSupportActionBar().setTitle(title);
//        }

    }
}
