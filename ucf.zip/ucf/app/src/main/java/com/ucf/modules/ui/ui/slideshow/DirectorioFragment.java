package com.ucf.modules.ui.ui.slideshow;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.adapters.ContactoAdapter;
import com.ucf.models.Contacto;
import com.ucf.utils.SQLHelper;
import com.ucf.utils.SearchHelper;

import java.util.ArrayList;

public class DirectorioFragment extends Fragment{

    private ListView directorio;
    private ContactoAdapter adapter;
    private SQLHelper database;
    ArrayList<Contacto> contactos;
    FloatingActionButton fab_filter;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_directorio, container, false);

        database = new SQLHelper(this.getContext());
        contactos = new ArrayList<>();
        try {
            database.open();
            contactos = database.getContactos();
            database.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


        directorio = root.findViewById(R.id.lista_contactos);
        adapter = new ContactoAdapter(contactos, this.getContext(), this.getActivity());
        directorio.setAdapter(adapter);

        fab_filter = root.findViewById(R.id.fab_filter);
        fab_filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(getContext());
                dialog.setContentView(R.layout.dialog_search);
                final EditText et_search = dialog.findViewById(R.id.et_search);
                final TextView txt_search, txt_cancelar;
                txt_search = dialog.findViewById(R.id.txt_search);
                txt_cancelar = dialog.findViewById(R.id.txt_cancelar);

                txt_search.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String search_term = et_search.getText().toString();
                        if(!search_term.equals("")){
                            filter(search_term.trim());
                            dialog.dismiss();
                        }
                    }
                });
                txt_cancelar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        return root;
    }

    public void filter(String search) {
        contactos = SearchHelper.getAgentes(getActivity().getBaseContext(), search);
        adapter = new ContactoAdapter(contactos, getActivity().getBaseContext(), getActivity());
        directorio.setAdapter(adapter);
    }

}