package com.ucf.modules.ui.ui.home;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.ucf.R;
import com.ucf.adapters.NoticiaAdapter;
import com.ucf.models.Noticia;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;

public class HomeFragment extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener{
    AppCompatActivity activity;
    private String url = "https://intranet.ucf.edu.cu/";
    private ArrayList<Noticia> noticias;
    View root;
    ProgressDialog progressDialog;
    public HomeFragment(AppCompatActivity activity){
        this.activity = activity;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
//        setHasOptionsMenu(true);
        root = inflater.inflate(R.layout.activity_scrolling, container, false);
        Toolbar toolbar = (Toolbar) root.findViewById(R.id.toolbar);
        toolbar.setTitle("Actualidad UCF");
        activity.setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) root.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                noticias.clear();
                new Description().execute();
            }
        });
        noticias = new ArrayList<>();

        new Description().execute();
        return root;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.reload, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_reload) {

//            new Description().execute();
            return true;
        }
        return false;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class Description extends AsyncTask<Void, Void, Void> {

        /**
         * Runs on the UI thread before {@link #doInBackground}.
         *
         * @see #onPostExecute
         * @see #doInBackground
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(getContext());
            progressDialog.setTitle("UCF");
            progressDialog.setTitle("Buscando informacion...");
            progressDialog.setIndeterminate(false);
            progressDialog.show();


        }

        /**
         * Override this method to perform a computation on a background thread. The
         * specified parameters are the parameters passed to {@link #execute}
         * by the caller of this task.
         * <p>
         * This method can call {@link #publishProgress} to publish updates
         * on the UI thread.
         *
         * @param voids The parameters of the task.
         * @return A result, defined by the subclass of this task.
         * @see #onPreExecute()
         * @see #onPostExecute
         * @see #publishProgress
         */
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Document document = Jsoup.connect(url).get();
                Elements elements = document.select("div[class=wp-show-posts-inner]");

                int elementsSize = elements.size();
                System.out.println(elementsSize);
                for (int i = 0; i < elementsSize; i++) {
                    Elements item_i = elements.eq(i);
                    String img = item_i.select("div").select("a").select("img").attr("src");
                    String titulo = item_i.select("header").select("p").text();
                    String link = item_i.select("header").select("p").select("a").attr("href");
                    String resumen = item_i.select("div[class=wp-show-posts-entry-summary]").select("p").text();
                    System.out.println(img);
                    noticias.add(new Noticia(titulo, resumen, link, img, (i <= 3) ? "Noticia UCF" : "Convocatoria UCF"));
                }
            } catch (IOException e) {
                Noticia noticia = new Noticia("Conexion fallida", "Parece que no estás conectado a ninguna red, o no tienes acceso a la UCF", "", "", "Conexion Fallida");
                noticia.setRes(R.drawable.illustration);
                noticias.add(noticia);
//                Toast.makeText(getActivity().getApplicationContext(), "Debes activar los datos moviles y tener al menos la bolsa de correo activa", Toast.LENGTH_SHORT).show();
            }

            return null;
        }

        /**
         * <p>Runs on the UI thread after {@link #doInBackground}. The
         * specified result is the value returned by {@link #doInBackground}.</p>
         * <p>
         * <p>This method won't be invoked if the task was cancelled.</p>
         *
         * @param aVoid The result of the operation computed by {@link #doInBackground}.
         * @see #onPreExecute
         * @see #doInBackground
         */
        @Override
        protected void onPostExecute(Void aVoid) {
            RecyclerView recyclerView = root.findViewById(R.id.list_news);
            NoticiaAdapter dataAdapter = new NoticiaAdapter(noticias, activity);
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext().getApplicationContext());
            recyclerView.setLayoutManager(layoutManager);
            recyclerView.setAdapter(dataAdapter);
            progressDialog.dismiss();
        }
    }


}