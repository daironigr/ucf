package com.ucf.utils;

import android.content.Context;
import android.widget.Toast;

import com.ucf.models.Contacto;

import java.util.ArrayList;

/**
 * Created by Apple on 16/5/2018.
 */

public class SearchHelper {

    public static int exist(String word, String text) {
        int k = 0;
        int i = 0;
        int[] f = kmp(word);

        if (text.length() >= word.length()) {
            f = kmp(word);
            while ((k + i) < text.length()) {
                if (word.charAt(i) == text.charAt(k + i)) {
                    if(i == word.length()-1) {
                        return k;
                    }
                    i += 1;
                }else {
                    k = k + i - f[i];
                    if(i > 0) {
                        i = f[i];
                    }
                }
            }
        }
        return -1;
    }

    private static int[] kmp(String word) {
        int[] f = new int[word.length() * 2];

        int pos = 2;
        int cnd = 0;

        f[0] = -1;
        f[1] = 0;

        while (pos <= word.length()) {
            if (word.charAt(pos - 1) == word.charAt(cnd)) {
                cnd += 1;
                f[pos] = cnd;
                pos += 1;
            } else if (cnd > 0) {
                cnd = f[cnd];
            } else {
                f[pos] = 0;
                pos = pos + 1;
            }
        }
        return f;
    }

    public static ArrayList<Contacto> getAgentes(Context context, String search) {
        ArrayList<Contacto> contactos = new ArrayList<>();
        SQLHelper sql = new SQLHelper(context);
        try {
            sql.open();
            contactos = sql.searchContacto(search);
            sql.close();
        } catch (Exception e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return contactos;
    }

}
