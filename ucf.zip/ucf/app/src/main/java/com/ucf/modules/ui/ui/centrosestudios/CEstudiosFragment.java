package com.ucf.modules.ui.ui.centrosestudios;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.modules.ui.ui.somos.SomosFragment;

public class CEstudiosFragment extends Fragment implements View.OnClickListener {
    private CardView cv_cetas,
            cv_ceddes,
            cv_cesoc,
            cv_ceema;
    private FloatingActionButton fab;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View root = inflater.inflate(R.layout.fragment_centroestudios, null);
        fab = root.findViewById(R.id.fab_back_to_somos);
        cv_cetas = root.findViewById(R.id.cv_cetas);
        cv_ceddes = root.findViewById(R.id.cv_ceddes);
        cv_cesoc = root.findViewById(R.id.cv_cesoc);
        cv_ceema = root.findViewById(R.id.cv_ceema);

        cv_cetas.setOnClickListener(this);
        cv_ceddes.setOnClickListener(this);
        cv_cesoc.setOnClickListener(this);
        cv_ceema.setOnClickListener(this);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new SomosFragment()).addToBackStack(null).commit();
            }
        });
        return root;
    }

    public void onClick(View view) {
        String url = "";
        switch (view.getId()) {
            case R.id.cv_cetas:
                url = "https://intranet.ucf.edu.cu/?page_id=1955";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_ceddes:
                url = "https://ceddes.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_cesoc:
                url = "https://intranet.ucf.edu.cu/?page_id=1936";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_ceema:
                url = "https://intranet.ucf.edu.cu/?page_id=1936";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
        }
    }
}
