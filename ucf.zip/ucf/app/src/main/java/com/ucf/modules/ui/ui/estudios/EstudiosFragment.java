package com.ucf.modules.ui.ui.estudios;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ucf.R;
import com.ucf.modules.ui.ui.estudios.pregrado.PregradoFragment;
import com.ucf.modules.ui.ui.somos.SomosFragment;

public class EstudiosFragment extends Fragment {
    private CardView cv_pregrado, cv_posgrado;
    private FloatingActionButton fab;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View root = inflater.inflate(R.layout.fragment_estudios, null);
        cv_pregrado = root.findViewById(R.id.cv_pregrado);
        cv_posgrado = root.findViewById(R.id.cv_posgrado);
        cv_pregrado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new PregradoFragment()).addToBackStack(null).commit();
            }
        });
        cv_posgrado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://intranet.ucf.edu.cu/?page_id=456";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
            }
        });
        fab = root.findViewById(R.id.fab_back_to_somos);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container_body, new SomosFragment()).addToBackStack(null).commit();
            }
        });
        return root;
    }
}
