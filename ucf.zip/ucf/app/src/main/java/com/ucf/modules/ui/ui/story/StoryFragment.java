package com.ucf.modules.ui.ui.story;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.ucf.R;
import com.ucf.accordion.widget.AccordionView;
import com.ucf.models.Etapa;
import com.ucf.utils.SQLHelper;

import java.util.ArrayList;

public class StoryFragment extends Fragment {

    SQLHelper database;
    TextView texto_1,
            texto_2,
            texto_3,
            texto_4,
            texto_5,
            texto_6,
            texto_7,
            texto_8,
            texto_9,
            texto_10,
            texto_11,
            texto_12;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        database = new SQLHelper(this.getContext());
        View root = inflater.inflate(R.layout.fragment_story, container, false);
        final AccordionView v = root.findViewById(R.id.accordion_view);

        ArrayList<Etapa> etapas = new ArrayList<>();
        try{
            database.open();
            etapas = database.getEtapas();
            database.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        texto_1 = root.findViewById(R.id.texto_etapa_1);
        texto_2 = root.findViewById(R.id.texto_etapa_2);
        texto_3 = root.findViewById(R.id.texto_etapa_3);
        texto_4 = root.findViewById(R.id.texto_etapa_4);
        texto_5 = root.findViewById(R.id.texto_etapa_5);
        texto_6 = root.findViewById(R.id.texto_etapa_6);
        texto_7 = root.findViewById(R.id.texto_etapa_7);
        texto_8 = root.findViewById(R.id.texto_etapa_8);
        texto_9 = root.findViewById(R.id.texto_etapa_9);
        texto_10 = root.findViewById(R.id.texto_etapa_10);
        texto_11 = root.findViewById(R.id.texto_intro);

        texto_1.setText(etapas.get(0).texto);
        texto_2.setText(etapas.get(1).texto);
        texto_3.setText(etapas.get(2).texto);
        texto_4.setText(etapas.get(3).texto);
        texto_5.setText(etapas.get(4).texto);
        texto_6.setText(etapas.get(5).texto);
        texto_7.setText(etapas.get(6).texto);
        texto_8.setText(etapas.get(7).texto);
        texto_9.setText(etapas.get(8).texto);
        texto_10.setText(etapas.get(9).texto);
        texto_11.setText(etapas.get(10).texto);
        return root;
    }
}