package com.ucf.modules.ui.ui.tools;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.ucf.R;


public class ToolsFragment extends Fragment implements View.OnClickListener {

    CardView correo, internet, cuenta, antivirus, directorio;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_tools, container, false);
        correo = root.findViewById(R.id.cv_correo);
        internet = root.findViewById(R.id.cv_internet);
        cuenta = root.findViewById(R.id.cv_cuenta);
        antivirus = root.findViewById(R.id.cv_antivirus);
//        directorio = root.findViewById(R.id.cv_directorio);

        correo.setOnClickListener(this);
        internet.setOnClickListener(this);
        cuenta.setOnClickListener(this);
        antivirus.setOnClickListener(this);
//        directorio.setOnClickListener(this);

        return root;
    }

    public void onClick(View view){
        String url = "";
        switch (view.getId()){
            case R.id.cv_correo:
                url = "https://webmail.ucf.edu.cu/SOGo/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_internet:
                url = "https://siccip.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_cuenta:
                url = "http://micuenta.ucf.edu.cu/login";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
            case R.id.cv_antivirus:
                url = "http://updates.ucf.edu.cu/";
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
                break;
//            case R.id.cv_directorio:
//                url = "https://webmail.ucf.edu.cu";
//                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
//                break;

        }
    }
}