package com.ucf.models;

import android.content.Context;

public class Info {
    public String titulo;
    public String info;
    public String[] info_array;

    public Info(String titulo, String info) {
        this.titulo = titulo;
        this.info = info;
        this.info_array = new String[]{};
    }

    public void loadArrayFromResource(Context context, int res){
        info_array = context.getResources().getStringArray(res);
    }
}
