package com.ucf.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.ucf.models.Etapa;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class Utiles {
    public static void readFile(Context context){
        String content = "";
        try {
            InputStream is = context.getAssets().open("etapas.csv");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            content = new String(buffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String splitted[] = content.split("#");
        for (int i = 0; i < splitted.length; i++) {
            System.out.println(splitted[i]);
        }
    }

    public static void call(String num, Context context, Activity activity) {
        if (Permission.checkPermission(context, Permission.P_CALL_PHONE)) {
            context.startActivity(new Intent("android.intent.action.CALL", Uri.parse("tel:" + num)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } else {
            Permission.requestPermission(activity, Permission.P_CALL_PHONE);
        }
    }

    @SuppressLint("IntentReset")
    public static void enviar(String[] to, String[] cc,
                              String asunto, String mensaje, Context context) {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        //String[] to = direccionesEmail;
        //String[] cc = copias;
        emailIntent.putExtra(Intent.EXTRA_EMAIL, to);
        emailIntent.putExtra(Intent.EXTRA_CC, cc);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, asunto);
        emailIntent.putExtra(Intent.EXTRA_TEXT, mensaje);
        emailIntent.setType("message/rfc822");
        context.startActivity(Intent.createChooser(emailIntent, "Email ").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
}
