package com.ucf.models;

public class Etapa {
    public String titulo;
    public String texto;

    public Etapa(String titulo, String texto) {
        this.titulo = titulo;
        this.texto = texto;
    }
}
