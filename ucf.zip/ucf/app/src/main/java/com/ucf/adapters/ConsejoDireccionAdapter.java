package com.ucf.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ucf.R;
import com.ucf.models.Consejo;
import com.ucf.models.Noticia;

import java.util.ArrayList;

import static com.ucf.utils.Utiles.enviar;

public class ConsejoDireccionAdapter extends RecyclerView.Adapter<ConsejoDireccionAdapter.MyViewHolder> {
    private ArrayList<Consejo> consejo_direccion = new ArrayList<>();
    private Context context;

    public ConsejoDireccionAdapter(ArrayList<Consejo> consejo_direccion, Context context) {
        this.consejo_direccion = consejo_direccion;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView cargo;
        public TextView nombre;
        private TextView correo;
        private ImageView img;

        public MyViewHolder(View view) {
            super(view);
            cargo = view.findViewById(R.id.txt_persona_cargo);
            nombre = view.findViewById(R.id.txt_persona_nombre);
            correo = view.findViewById(R.id.txt_persona_correo);
            img = view.findViewById(R.id.avatar);

        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_persona, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public int getItemCount() {
        return consejo_direccion.size();
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final Consejo persona = consejo_direccion.get(position);
        holder.cargo.setText(persona.cargo);
        holder.nombre.setText(persona.nombre);
        holder.correo.setText(persona.correo);
        holder.img.setImageBitmap(persona.getImageBmp());

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                enviar(new String[]{persona.correo}, null, "Hola", "", context);
                return true;
            }
        });

        holder.itemView.setBackgroundColor(context.getResources().getColor((position % 2 == 0) ? R.color.colorAccent : R.color.colorPrimaryDark));
    }
}
